package com.hugogabr.webview;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebChromeClient; // Importação adicionada
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class WebViewHelper {
private static final String TAG = "GeodeWebViewHelper"; // Tag Log mais descritiva
private static WebView webView;

/**  
 * Abre um WebView em tela cheia com a URL especificada.  
 * Deve ser chamado do código C++ (JNI).  
 * @param url A URL a ser carregada.  
 */  
public static void openWebView(String url) {  
    Log.i(TAG, "Abrindo WebView com URL: " + url);  

    Activity activity = com.geode.bridge.GeodeActivityBridge.getActivity();  
    if (activity == null) {  
        Log.e(TAG, "Atividade principal não encontrada (GeodeActivityBridge).");  
        return;  
    }  

    activity.runOnUiThread(() -> {  
        try {  
            // 1. Garante que o WebView anterior seja limpo e removido corretamente.  
            if (webView != null) {  
                removeWebView(activity);  
            }  

            // 2. Cria e configura o novo WebView  
            webView = new WebView(activity);  
              
            // Configurações básicas de desempenho e compatibilidade  
            webView.getSettings().setJavaScriptEnabled(true);  
            webView.getSettings().setDomStorageEnabled(true);  
            webView.getSettings().setAllowFileAccess(true);  
            // Permite melhor experiência de visualização em dispositivos móveis  
            webView.getSettings().setLoadWithOverviewMode(true);  
            webView.getSettings().setUseWideViewPort(true);   
              
            // Define o WebChromeClient (para popups JS, loading progress, etc.)  
            webView.setWebChromeClient(new WebChromeClient());  
              
            // Define o WebViewClient customizado para controle de navegação  
            webView.setWebViewClient(new CustomWebViewClient(activity));  
              
            // Lidar com o botão de Voltar do Android dentro do WebView  
            webView.setOnKeyListener((v, keyCode, event) -> {  
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_BACK) {  
                    if (webView.canGoBack()) {  
                        webView.goBack();  
                        return true; // Consome o evento  
                    } else {  
                        // Se não puder voltar, permite que o evento feche o WebView (ou o que o sistema faria)  
                        return false;   
                    }  
                }  
                return false;  
            });  

            webView.loadUrl(url);  

            // 3. Adiciona o WebView à tela do jogo  
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(  
                FrameLayout.LayoutParams.MATCH_PARENT,  
                FrameLayout.LayoutParams.MATCH_PARENT  
            );  
            // Usa o ID para uma referência mais robusta (opcional, mas bom padrão)  
            webView.setId(android.R.id.content + 1);   
              
            ((FrameLayout) activity.getWindow().getDecorView()).addView(webView, params);  

            Log.i(TAG, "WebView carregado com sucesso.");  
        } catch (Exception e) {  
            Log.e(TAG, "Erro fatal ao abrir WebView: " + e.getMessage(), e); // Loga a stack trace  
            // Opcional: Mostrar um Toast de erro para o usuário aqui.  
        }  
    });  
}  

/**  
 * Remove e destrói o WebView.  
 */  
public static void closeWebView() {  
    Activity activity = com.geode.bridge.GeodeActivityBridge.getActivity();  
    if (activity == null || webView == null) return;  

    activity.runOnUiThread(() -> {  
        removeWebView(activity);  
        Log.i(TAG, "WebView fechado e destruído.");  
    });  
}  

/**  
 * Lógica de limpeza do WebView, extraída para reuso.  
 * @param activity A atividade principal.  
 */  
private static void removeWebView(Activity activity) {  
    if (webView != null) {  
        // Garante que o WebView pare qualquer carregamento ativo  
        webView.stopLoading();   
        // Remove o WebView do layout  
        ((FrameLayout) activity.getWindow().getDecorView()).removeView(webView);  
        // Destrói a instância  
        webView.destroy();  
        webView = null;  
    }  
}  
  
/**  
 * WebViewClient customizado para lidar com a navegação.  
 */  
private static class CustomWebViewClient extends WebViewClient {  
    private final Activity mActivity;  

    public CustomWebViewClient(Activity activity) {  
        this.mActivity = activity;  
    }  

    @Override  
    public boolean shouldOverrideUrlLoading(WebView view, String url) {  
        // Usa Uri.parse(url) e a intent para lidar com todos os esquemas (http/https/outros)  
        Uri uri = Uri.parse(url);  
          
        // 1. Se for uma URL http/https, permite que o WebView tente carregar *internamente*.  
        if (url.startsWith("http://") || url.startsWith("https://")) {  
            // view.loadUrl(url); // Não precisa, o retorno 'false' faz isso.  
            return false; // Retorna false para permitir que o WebView lide com o URL  
        }   
          
        // 2. Para qualquer outro esquema (tel:, mailto:, ou links externos não-http),  
        // tenta abrir com uma Activity externa (navegador, app de e-mail, etc.).  
        else {  
            try {  
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
                // Adiciona a flag para garantir que a nova Activity não volte para o jogo  
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);   
                mActivity.startActivity(intent);  
                  
                // Retorna true para indicar que o host application lidou com o URL,   
                // impedindo que o WebView tente carregar.  
                return true;  
            } catch (Exception e) {  
                Log.e(TAG, "Não foi possível abrir link externo: " + url, e);  
                // Retorna false para permitir que o WebView tente carregar (embora vá falhar)  
                return false;   
            }  
        }  
    }  
}

}


#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <jni.h> // Importante para as chamadas JNI

// Garante que o namespace geode::prelude esteja disponível
using namespace geode::prelude;

// O uso do ID "bottom-menu" é comum, mas é bom ter uma verificação
static constexpr auto BOTTOM_MENU_ID = "bottom-menu"_spr;
static constexpr auto WEBVIEW_BTN_ID = "webview-btn"_spr;
static constexpr float PADDING_VALUE = 15.0f;

class $modify(MyMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        // 1. Verificação de existência do menu principal
        auto menu = this->getChildByID(BOTTOM_MENU_ID);
        if (!menu) {
            // Se o menu não existir (o que é improvável no MenuLayer, mas bom para robustez)
            return true;
        }

        // 2. Cria o CCMenuItemSpriteExtra
        auto btn = CCMenuItemSpriteExtra::create(
            CCSprite::createWithSpriteFrameName("GJ_browserBtn_001.png"),
            this,
            menu_selector(MyMenuLayer::onOpenWebView)
        );

        // 3. Define o ID e adiciona ao menu
        btn->setID(WEBVIEW_BTN_ID);
        menu->addChild(btn);
        
        // 4. Reorganiza os itens do menu
        // É crucial chamar isso APÓS adicionar o novo item
        menu->alignItemsHorizontallyWithPadding(PADDING_VALUE);

        return true;
    }

    // 5. Usa a convenção de macro Geode para o callback: $onButtonTrigger
    // Embora menu_selector funcione, $onButtonTrigger é mais idiomático para modding Geode.
    void onOpenWebView(CCObject*) {
        // Obtenção da URL
        auto mod = Mod::get();
        // Usa o método getSettingValue para obter a string diretamente
        auto url = mod->getSettingValue<std::string>("url");

        // Log antes da chamada JNI para melhor rastreamento
        log::info("Tentando abrir WebView com URL: {}", url);

        // 6. Refinamento da chamada JNI
        // O escopo e a liberação de referências locais são importantes aqui
        
        JNIEnv* env = geode::jni::getEnv();
        if (!env) {
            log::error("Falha ao obter JNI environment!");
            return;
        }

        // Busca pela classe Java. Uma referência local será retornada.
        jclass cls = env->FindClass("com/hugogabr/webview/WebViewHelper");
        if (!cls) {
            log::error("Classe Java 'com/hugogabr/webview/WebViewHelper' não encontrada!");
            return;
        }

        // Busca pelo método estático
        jmethodID mid = env->GetStaticMethodID(cls, "openWebView", "(Ljava/lang/String;)V");
        if (!mid) {
            log::error("Método estático 'openWebView(Ljava/lang/String;)' não encontrado!");
            // IMPORTANTE: Liberar a referência local da classe
            env->DeleteLocalRef(cls); 
            return;
        }

        // Cria a string Java a partir da string C++
        jstring jurl = env->NewStringUTF(url.c_str());
        // Se a criação da string falhar
        if (env->ExceptionCheck()) {
            log::error("Falha ao criar jstring para a URL.");
            env->ExceptionClear(); // Limpa a exceção
            env->DeleteLocalRef(cls);
            return;
        }

        // Chama o método estático
        env->CallStaticVoidMethod(cls, mid, jurl);
        
        // 7. Limpeza de referências locais (crucial em JNI)
        env->DeleteLocalRef(jurl);
        env->DeleteLocalRef(cls); // Libera a referência local da classe

        log::info("Chamada JNI para abrir WebView concluída.");
    }
};
